const form = document.getElementById('formII')

function exibir(){
    form.style.visibility="visible"
}