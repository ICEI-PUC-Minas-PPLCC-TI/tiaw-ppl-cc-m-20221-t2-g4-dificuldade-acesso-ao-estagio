
const form = document.getElementById('formIII')

function exibir(){
    form.style.visibility="visible"
}