const form = document.getElementById('formIV')

function exibir(){
    form.style.visibility="visible"
}