function avancar(type){
    if(type == 'es'){
    window.open('../vagas_estagiario/index.html')
    }else{
    window.open('../listar_empresas/index.html')
    }
}