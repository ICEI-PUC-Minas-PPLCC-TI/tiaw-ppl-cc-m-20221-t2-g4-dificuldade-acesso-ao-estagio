# Documentação do Projeto

A documentação do projeto é composta pelos seguintes itens: 
 - [Processo de Design Thinking](concepcao/Processo%20Design%20Thinking%20-%20TEMPLATE.pdf)
 - [Relatório Técnico](relatorio/Relatorio%20Tecnico%20-%20TEMPLATE.md)
 - [Apresentação do Projeto](apresentacao/apresentacao%20-%20TEMPLATE.pptx)
 - [Vídeo de Demonstração](https://youtube.com)

